
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

DATASET_PATH = "example_eeg_dataset/"

classes = ["left", "right", "forward", "stop"]

data_frames = []
for label in classes:
    df = pd.read_csv(DATASET_PATH + label + ".csv")
    data_frames.append(df)

data = pd.concat(data_frames, ignore_index=True)

def extract_features(df):
    features = pd.DataFrame()
    features["mean_ch1"] = df["ch1"]
    features["mean_ch2"] = df["ch2"]
    features["mean_ch3"] = df["ch3"]
    features["mean_ch4"] = df["ch4"]

    features["var_ch1"] = df["ch1"].rolling(3, min_periods=1).var().fillna(0)
    features["var_ch2"] = df["ch2"].rolling(3, min_periods=1).var().fillna(0)
    features["var_ch3"] = df["ch3"].rolling(3, min_periods=1).var().fillna(0)
    features["var_ch4"] = df["ch4"].rolling(3, min_periods=1).var().fillna(0)
    return features

features = extract_features(data)
labels = data["label"]

X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.3, random_state=42, shuffle=True)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

clf = RandomForestClassifier(n_estimators=120, random_state=42)
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Report:\n", classification_report(y_test, y_pred))
